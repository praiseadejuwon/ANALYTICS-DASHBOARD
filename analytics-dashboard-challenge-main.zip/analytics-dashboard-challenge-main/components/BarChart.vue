<template>
  <Bar :data="data" :options="options" />
</template>

<script lang="ts">
import {
  Chart as ChartJS,
  Title,
  Tooltip,
  Legend,
  BarElement,
  CategoryScale,
  LinearScale,
} from "chart.js";
import { Bar } from "vue-chartjs";
import * as chartConfig from "./chartConfig.js";

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip);

export default {
  name: "App",
  components: {
    Bar,
  },
  data() {
    return chartConfig;
  },
};
</script>
