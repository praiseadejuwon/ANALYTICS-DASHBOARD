<template>
  <div>
    <h1>Color mode: {{ $colorMode.value }}</h1>
    <select v-model="$colorMode.value">
      <option value="system">System</option>
      <option value="light">Light</option>
      <option value="dark">Dark</option>
      <option value="sepia">Sepia</option>
    </select>
  </div>
</template>

<script setup>
const colorMode = useColorMode();
colorMode.value = "light"

// console.log(colorMode);
</script>

<style>
.sepia-mode body {
  background-color: var(--color-red);
  color: #433422;
}
</style>
