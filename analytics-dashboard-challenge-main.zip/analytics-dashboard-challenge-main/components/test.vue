<template>
    <div>
        <h1>
            dhkfhkgjfsdkhldhfgsjhlkjdkgkk
        </h1>
    </div>
</template>

<style scoped>
.dark h1 {
    
}
</style>